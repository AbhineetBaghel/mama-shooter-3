gdjs.game_32overCode = {};
gdjs.game_32overCode.GDBushBackgroundObjects1= [];
gdjs.game_32overCode.GDBushBackgroundObjects2= [];
gdjs.game_32overCode.GDHouseTallForegroundObjects1= [];
gdjs.game_32overCode.GDHouseTallForegroundObjects2= [];
gdjs.game_32overCode.GDHouseSmallBackgroundObjects1= [];
gdjs.game_32overCode.GDHouseSmallBackgroundObjects2= [];
gdjs.game_32overCode.GDPurpleBackgroundObjects1= [];
gdjs.game_32overCode.GDPurpleBackgroundObjects2= [];
gdjs.game_32overCode.GDnoObjects1= [];
gdjs.game_32overCode.GDnoObjects2= [];

gdjs.game_32overCode.conditionTrue_0 = {val:false};
gdjs.game_32overCode.condition0IsTrue_0 = {val:false};


gdjs.game_32overCode.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}}

}


};

gdjs.game_32overCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.game_32overCode.GDBushBackgroundObjects1.length = 0;
gdjs.game_32overCode.GDBushBackgroundObjects2.length = 0;
gdjs.game_32overCode.GDHouseTallForegroundObjects1.length = 0;
gdjs.game_32overCode.GDHouseTallForegroundObjects2.length = 0;
gdjs.game_32overCode.GDHouseSmallBackgroundObjects1.length = 0;
gdjs.game_32overCode.GDHouseSmallBackgroundObjects2.length = 0;
gdjs.game_32overCode.GDPurpleBackgroundObjects1.length = 0;
gdjs.game_32overCode.GDPurpleBackgroundObjects2.length = 0;
gdjs.game_32overCode.GDnoObjects1.length = 0;
gdjs.game_32overCode.GDnoObjects2.length = 0;

gdjs.game_32overCode.eventsList0(runtimeScene);

return;

}

gdjs['game_32overCode'] = gdjs.game_32overCode;
